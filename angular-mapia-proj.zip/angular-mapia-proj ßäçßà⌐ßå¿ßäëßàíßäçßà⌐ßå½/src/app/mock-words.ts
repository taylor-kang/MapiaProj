import { Word } from './word';

export const WORDS: Word[] = [
	{ name: 'MrNice', x: 0, y: 0},
  	{ name: 'Narco', x: 0, y: 0},
    { name: 'Bombasto', x: 0, y: 0},
    { name: 'Celeritas', x: 0, y: 0 },
    { name: 'Magneta', x: 0, y: 0 },
    { name: 'RubberMan', x: 0, y: 0 },
    { name: 'Dynama', x: 0, y: 0 },
    { name: 'DrIQ', x: 0, y: 0 },
    { name: 'Magma', x: 0, y: 0 },
    { name: 'Tornado', x: 0, y: 0 },
    { name: 'everyday', x: 0, y: 0 },
    { name: 'christmas', x: 0, y: 0 },
    { name: 'winter', x: 0, y: 0 },
    { name: 'hanyang', x: 0, y: 0 },
    { name: 'mapiaCompany', x: 0, y: 0 },
];
