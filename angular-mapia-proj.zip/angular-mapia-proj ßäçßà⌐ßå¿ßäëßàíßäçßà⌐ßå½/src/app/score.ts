export class Score {
    level: number;
    success: number;
    fail: number;    
    
    constructor() {
    	this.level = 0;
    	this.success = 0;
    	this.fail = 0;
  }
}
