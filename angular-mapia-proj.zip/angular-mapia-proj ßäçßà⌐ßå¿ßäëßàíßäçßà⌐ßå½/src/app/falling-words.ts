import { Word } from './word';

export const FALLING_WORDS: Word[] = [ 
   
];
