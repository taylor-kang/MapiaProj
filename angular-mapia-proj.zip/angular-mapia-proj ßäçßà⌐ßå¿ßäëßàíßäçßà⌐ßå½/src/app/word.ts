export class Word {
    name: string;
    x: number;
    y: number;

    constructor(name, x, y){
    	this.name= name;
    	this.x = x;
    	this.y= y;
    }
}
